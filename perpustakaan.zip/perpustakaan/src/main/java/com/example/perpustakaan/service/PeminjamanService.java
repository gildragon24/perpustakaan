package com.example.perpustakaan.service;

import com.example.perpustakaan.entity.Peminjaman;
import com.example.perpustakaan.repository.PeminjamanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PeminjamanService {

    @Autowired
    private PeminjamanRepository peminjamanRepository;

    public List<Peminjaman> getAllPeminjaman() {
        return peminjamanRepository.findAll();
    }

    public Optional<Peminjaman> getPeminjamanById(Integer id) {
        return peminjamanRepository.findById(id);
    }

    public Peminjaman savePeminjaman(Peminjaman peminjaman) {
        return peminjamanRepository.save(peminjaman);
    }

    public void deletePeminjaman(Integer id) {
        peminjamanRepository.deleteById(id);
    }
}
