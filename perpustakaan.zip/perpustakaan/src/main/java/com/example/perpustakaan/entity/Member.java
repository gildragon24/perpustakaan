package com.example.perpustakaan.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "member")
public class Member extends User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer member_id;

    @Column(name = "statusAnggota", nullable = false)
    private Boolean statusAnggota;

    @Column(name = "peminjaman_id", nullable = true)
    private Integer peminjaman_id;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "email", nullable = false)
    private String email;

    // Constructor
    public Member(Integer member_id, String username, String password, String email, Boolean statusAnggota, Integer peminjaman_id) {
        super(username, password, email);
        this.member_id = member_id;
        this.statusAnggota = statusAnggota;
        this.peminjaman_id = peminjaman_id;
    }

    

    // Getters and Setters
    public Integer getMember_id() {
        return member_id;
    }

    public void setMember_id(Integer member_id) {
        this.member_id = member_id;
    }

    public Boolean getStatusAnggota() {
        return statusAnggota;
    }

    public void setStatusAnggota(Boolean statusAnggota) {
        this.statusAnggota = statusAnggota;
    }

    public Integer getPeminjaman_id() {
        return peminjaman_id;
    }

    public void setPeminjaman_id(Integer peminjaman_id) {
        this.peminjaman_id = peminjaman_id;
    }

    @Override
    public void logout() {
        // Custom logic for Member logout
        System.out.println("Member logged out.");
    }
}
