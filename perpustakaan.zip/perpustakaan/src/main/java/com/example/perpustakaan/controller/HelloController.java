package com.example.perpustakaan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
    public class HelloController {
    @GetMapping("/")
    @ResponseBody
    public String tes() {
        return "Hello world wide web!";
    }
    @GetMapping("/home.html")
    public String home(){
        return "home.html";
    }

    @GetMapping("/about.html")
    public String about(){
        return "about.html";
    }

    @GetMapping("/admin.html")
    public String admin(){
        return "admin.html";
    }

    @GetMapping("/fasilitas.html")
    public String fasilitas(){
        return "fasilitas.html";
    }

    @GetMapping("/index.html")
    public String index(){
        return "index.html";
    }

    @GetMapping("/menuadmin.html")
    public String menuadmin(){
        return "menuadmin.html";
    }

    @GetMapping("/peminjaman.html")
    public String peminjaman(){
        return "peminjaman.html";
    }


    @GetMapping("/signup.html")
    public String signup(){
        return "signup.html";
    }

    @GetMapping("/member.html")
    public String member(){
        return "member.html";
    }

    
}