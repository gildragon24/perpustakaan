package com.example.perpustakaan.repository;

import com.example.perpustakaan.entity.Fasilitas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FasilitasRepository extends JpaRepository<Fasilitas, Integer> {
}
