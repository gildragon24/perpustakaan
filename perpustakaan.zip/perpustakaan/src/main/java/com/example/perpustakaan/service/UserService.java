package com.example.perpustakaan.service;

import com.example.perpustakaan.entity.User;
import com.example.perpustakaan.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Menyimpan atau memperbarui pengguna
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // Mendapatkan semua pengguna
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // Mendapatkan pengguna berdasarkan ID
    public Optional<User> getUserById(Integer id) {
        return userRepository.findById(id);
    }

    // Mencari pengguna berdasarkan username
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // Mencari pengguna berdasarkan email
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // Menghapus pengguna berdasarkan ID
    public void deleteUser(Integer id) {
        userRepository.deleteById(id);
    }
}
