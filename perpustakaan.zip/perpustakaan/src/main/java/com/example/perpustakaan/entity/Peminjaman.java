package com.example.perpustakaan.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "peminjaman")
public class Peminjaman {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer peminjaman_id;

    @ManyToOne
    @JoinColumn(name = "fasilitas_id", nullable = false)
    private Fasilitas fasilitas;

    @Column(name = "statusPeminjaman", nullable = false)
    private Boolean statusPeminjaman;

    @Column(name = "tanggal_pinjam", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date tanggal_pinjam;

    @OneToOne(mappedBy = "peminjaman", cascade = CascadeType.ALL)
    private Pengembalian pengembalian;

    // Constructors
    public Peminjaman() {}

    public Peminjaman(Integer peminjaman_id, Fasilitas fasilitas, Boolean statusPeminjaman, Date tanggal_pinjam) {
        this.peminjaman_id = peminjaman_id;
        this.fasilitas = fasilitas;
        this.statusPeminjaman = statusPeminjaman;
        this.tanggal_pinjam = tanggal_pinjam;
    }

    // Getters and Setters
    public Integer getPeminjaman_id() {
        return peminjaman_id;
    }

    public void setPeminjaman_id(Integer peminjaman_id) {
        this.peminjaman_id = peminjaman_id;
    }

    public Fasilitas getFasilitas() {
        return fasilitas;
    }

    public void setFasilitas(Fasilitas fasilitas) {
        this.fasilitas = fasilitas;
    }

    public Boolean getStatusPeminjaman() {
        return statusPeminjaman;
    }

    public void setStatusPeminjaman(Boolean statusPeminjaman) {
        this.statusPeminjaman = statusPeminjaman;
    }

    public Date getTanggal_pinjam() {
        return tanggal_pinjam;
    }

    public void setTanggal_pinjam(Date tanggal_pinjam) {
        this.tanggal_pinjam = tanggal_pinjam;
    }

    public Pengembalian getPengembalian() {
        return pengembalian;
    }

    public void setPengembalian(Pengembalian pengembalian) {
        this.pengembalian = pengembalian;
    }
}
