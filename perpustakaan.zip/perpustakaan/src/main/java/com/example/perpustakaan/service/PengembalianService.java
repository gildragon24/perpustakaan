package com.example.perpustakaan.service;

import com.example.perpustakaan.entity.Pengembalian;
import com.example.perpustakaan.repository.PengembalianRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PengembalianService {

    @Autowired
    private PengembalianRepository pengembalianRepository;

    public List<Pengembalian> getAllPengembalian() {
        return pengembalianRepository.findAll();
    }

    public Optional<Pengembalian> getPengembalianById(Integer id) {
        return pengembalianRepository.findById(id);
    }

    public Pengembalian savePengembalian(Pengembalian pengembalian) {
        return pengembalianRepository.save(pengembalian);
    }

    public void deletePengembalian(Integer id) {
        pengembalianRepository.deleteById(id);
    }
}
