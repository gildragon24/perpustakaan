package com.example.perpustakaan.controller;

import com.example.perpustakaan.entity.Pengembalian;
import com.example.perpustakaan.service.PengembalianService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/pengembalian")
public class PengembalianController {

    @Autowired
    private PengembalianService pengembalianService;

    @GetMapping
    public List<Pengembalian> getAllPengembalian() {
        return pengembalianService.getAllPengembalian();
    }

    @GetMapping("/{id}")
    public Optional<Pengembalian> getPengembalianById(@PathVariable Integer id) {
        return pengembalianService.getPengembalianById(id);
    }

    @PostMapping
    public Pengembalian createPengembalian(@RequestBody Pengembalian pengembalian) {
        return pengembalianService.savePengembalian(pengembalian);
    }

    @DeleteMapping("/{id}")
    public void deletePengembalian(@PathVariable Integer id) {
        pengembalianService.deletePengembalian(id);
    }
}
