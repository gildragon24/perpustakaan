package com.example.perpustakaan.entity;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "pengembalian")
public class Pengembalian {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer pengembalian_id;

    @OneToOne
    @JoinColumn(name = "peminjaman_id", nullable = false)
    private Peminjaman peminjaman;

    @Column(name = "review", nullable = true)
    private String review;

    @Column(name = "tanggal_kembali", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date tanggal_kembali;

    // Constructors
    public Pengembalian() {}

    public Pengembalian(Integer pengembalian_id, Peminjaman peminjaman, String review, Date tanggal_kembali) {
        this.pengembalian_id = pengembalian_id;
        this.peminjaman = peminjaman;
        this.review = review;
        this.tanggal_kembali = tanggal_kembali;
    }

    // Getters and Setters
    public Integer getPengembalian_id() {
        return pengembalian_id;
    }

    public void setPengembalian_id(Integer pengembalian_id) {
        this.pengembalian_id = pengembalian_id;
    }

    public Peminjaman getPeminjaman() {
        return peminjaman;
    }

    public void setPeminjaman(Peminjaman peminjaman) {
        this.peminjaman = peminjaman;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Date getTanggal_kembali() {
        return tanggal_kembali;
    }

    public void setTanggal_kembali(Date tanggal_kembali) {
        this.tanggal_kembali = tanggal_kembali;
    }
}
