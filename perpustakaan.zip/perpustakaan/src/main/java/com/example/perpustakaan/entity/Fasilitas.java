package com.example.perpustakaan.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "fasilitas")
public class Fasilitas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer fasilitas_id;

    @Column(name = "tipe", nullable = false)
    private String tipe;

    @Column(name = "status", nullable = false)
    private Boolean status;

    // Constructor
    public Fasilitas(Integer fasilitas_id, String tipe, Boolean status) {
        this.fasilitas_id = fasilitas_id;
        this.tipe = tipe;
        this.status = status;
    }


    // Getters and Setters
    public Integer getFasilitas_id() {
        return fasilitas_id;
    }

    public void setFasilitas_id(Integer fasilitas_id) {
        this.fasilitas_id = fasilitas_id;
    }

    public String getTipe() {
        return tipe;
    }

    public void setTipe(String tipe) {
        this.tipe = tipe;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }
}
