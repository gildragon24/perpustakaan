package com.example.perpustakaan.service;

import com.example.perpustakaan.entity.Fasilitas;
import com.example.perpustakaan.repository.FasilitasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FasilitasService {

    @Autowired
    private FasilitasRepository fasilitasRepository;

    public List<Fasilitas> getAllFasilitas() {
        return fasilitasRepository.findAll();
    }

    public Optional<Fasilitas> getFasilitasById(Integer id) {
        return fasilitasRepository.findById(id);
    }

    public Fasilitas saveFasilitas(Fasilitas fasilitas) {
        return fasilitasRepository.save(fasilitas);
    }

    public void deleteFasilitas(Integer id) {
        fasilitasRepository.deleteById(id);
    }
}
