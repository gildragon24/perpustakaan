package com.example.perpustakaan.controller;

import com.example.perpustakaan.entity.Fasilitas;
import com.example.perpustakaan.service.FasilitasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/fasilitas")
public class FasilitasController {

    @Autowired
    private FasilitasService fasilitasService;

    @GetMapping
    public List<Fasilitas> getAllFasilitas() {
        return fasilitasService.getAllFasilitas();
    }

    @GetMapping("/{id}")
    public Optional<Fasilitas> getFasilitasById(@PathVariable Integer id) {
        return fasilitasService.getFasilitasById(id);
    }

    @PostMapping
    public Fasilitas createFasilitas(@RequestBody Fasilitas fasilitas) {
        return fasilitasService.saveFasilitas(fasilitas);
    }

    @DeleteMapping("/{id}")
    public void deleteFasilitas(@PathVariable Integer id) {
        fasilitasService.deleteFasilitas(id);
    }
}
