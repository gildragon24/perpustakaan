package com.example.perpustakaan.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "admin")
public class Admin extends User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer admin_id;

    
    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "password", nullable = false)
    private String password;

    @Column(name = "email", nullable = false)
    private String email;

    // Constructor
    public Admin(Integer admin_id, String username, String password, String email) {
        super(username, password, email);
        this.admin_id = admin_id;
    }

  

    // Getters and Setters
    public Integer getAdmin_id() {
        return admin_id;
    }

    public void setAdmin_id(Integer admin_id) {
        this.admin_id = admin_id;
    }

    @Override
    public void logout() {
        // Custom logic for Admin logout
        System.out.println("Admin logged out.");
    }
}
